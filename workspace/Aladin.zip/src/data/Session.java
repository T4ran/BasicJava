/*
현재 로그인되어있는 사용자를 기억하기위한 클래스
*/
package data;

import vo.UserVO;

public class Session {
	//로그인 되어 있는 유저의 정보를 저장
	public static UserVO loginUser;
}

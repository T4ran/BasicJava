package service;

public interface SellRegisterService {   //판매등록

	void answer();			      //  답변받기

	void deleteSellBook();
}

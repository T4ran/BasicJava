package service;

public interface SearchService {

	void search();			 //도서 검색 기능
	
	void searchSelect();	 //도서 검색 이후 선택지
	
}
